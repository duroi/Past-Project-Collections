=============== README ==================================

Compile maze.cpp with: g++ maze.cpp -o maze
Program should compile with out issue but I have heard from other students about memory issues which require increasing the stack size to function.
In the main function the program is set to open and read from "input.txt".
File writes out to "output.txt" containing the moves and spaces need to reach Jojo from the starting tile.

Contact me at duroi@usf.edu if there are any issues.